package com.example.photogalleryapp
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.photogalleryapp.R

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var imageAdapter: ImageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // List of image URLs (these can be local file paths or URLs from the web)
        val imageUrls = listOf(
            "https://via.placeholder.com/150",
            "https://via.placeholder.com/200",
            "https://via.placeholder.com/300",
            "https://via.placeholder.com/150",
            "https://via.placeholder.com/200",
            "https://via.placeholder.com/300",
            "https://via.placeholder.com/150",
            "https://via.placeholder.com/200",
            "https://via.placeholder.com/300",
            "https://via.placeholder.com/150",
            "https://via.placeholder.com/200",
            "https://via.placeholder.com/300",
            "https://via.placeholder.com/150",
            "https://via.placeholder.com/200",
            "https://via.placeholder.com/300",
            "https://via.placeholder.com/150",
            "https://via.placeholder.com/200",
            "https://via.placeholder.com/300",
            "https://via.placeholder.com/150",
            "https://via.placeholder.com/200",
            "https://via.placeholder.com/300",
            "https://via.placeholder.com/150",
            "https://via.placeholder.com/200",
            "https://via.placeholder.com/300"
        )


        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 3) // Display images in a 3-column grid
        imageAdapter = ImageAdapter(imageUrls)
        recyclerView.adapter = imageAdapter
    }
}
